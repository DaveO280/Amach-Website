'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Loader2, CheckCircle, AlertCircle, Mail, Shield, Gift, ExternalLink } from 'lucide-react';
import { useZkSyncSsoWallet } from '@/hooks/useZkSyncSsoWallet';

interface VerificationStatus {
  isVerified: boolean;
  email?: string;
  userId?: number;
  tokenAllocation?: string;
  hasReceivedTokens?: boolean;
  verificationDate?: string;
}

interface AllocationInfo {
  totalAllocated: number;
  remainingAllocations: number;
  allocationPerUser: string;
  isActive: boolean;
}

export const ProfileVerificationFlow: React.FC = () => {
  const [email, setEmail] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [verificationStatus, setVerificationStatus] = useState<VerificationStatus | null>(null);
  const [allocationInfo, setAllocationInfo] = useState<AllocationInfo | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [step, setStep] = useState<'email' | 'verify' | 'complete'>('email');
  // Use ZKsync SSO wallet hook
  const {
    isConnected: isWalletConnected,
    isConnecting: isWalletConnecting,
    address: walletAddress,
    connect: connectWallet,
    error: walletError
  } = useZkSyncSsoWallet();

  // Check verification status and load allocation info on mount
  useEffect(() => {
    loadAllocationInfo();
  }, []);

  // Check verification status when wallet connects
  useEffect(() => {
    if (isWalletConnected && walletAddress) {
      // This function doesn't exist in the old component, so we'll remove this call
      console.log('Wallet connected:', walletAddress);
    }
  }, [isWalletConnected, walletAddress]);

  const loadAllocationInfo = async (): Promise<void> => {
    try {
      const response = await fetch('/api/verification/allocation-info');
      const data = await response.json();
      setAllocationInfo(data);
    } catch (error) {
      console.error('Failed to load allocation info:', error);
    }
  };

  const checkEmailWhitelist = async (email: string): Promise<boolean> => {
    try {
      const response = await fetch('/api/verification/check-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email })
      });
      
      const data = await response.json();
      return data.isWhitelisted;
    } catch (error) {
      console.error('Failed to check email whitelist:', error);
      return false;
    }
  };

  const handleEmailSubmit = async (e: React.FormEvent): Promise<void> => {
    e.preventDefault();
    
    if (!email) {
      setError('Please enter your email address');
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      const isWhitelisted = await checkEmailWhitelist(email);
      
      if (!isWhitelisted) {
        setError('Your email address is not whitelisted. Please contact support to request access.');
        setIsLoading(false);
        return;
      }

      // Check if email is already verified
      const response = await fetch('/api/verification/check-status', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email })
      });
      
      const data = await response.json();
      
      if (data.isVerified) {
        setVerificationStatus(data);
        setStep('complete');
      } else {
        setStep('verify');
      }
    } catch (error) {
      setError('Failed to verify email. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleWalletVerification = async (): Promise<void> => {
    if (!isWalletConnected) {
      setError('Please connect your wallet first');
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      // This would integrate with your existing wallet service
      // const signature = await signMessage(email + walletAddress);
      
      // For now, we'll simulate the verification
      const response = await fetch('/api/verification/verify-profile', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          email, 
          walletAddress: '0x1234...5678', // This would be the actual wallet address
          signature: 'mock_signature' // This would be the actual signature
        })
      });

      const data = await response.json();
      
      if (data.success) {
        setVerificationStatus(data.verification);
        setSuccess('Profile verified successfully! Your AHP tokens have been allocated.');
        setStep('complete');
      } else {
        setError(data.error || 'Verification failed');
      }
    } catch (error) {
      setError('Failed to verify profile. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleConnectWallet = async (): Promise<void> => {
    try {
      setError(null);
      const result = await connectWallet();
      if (!result.success) {
        setError(result.error || 'Failed to connect wallet');
      }
    } catch (error) {
      setError('Failed to connect wallet');
    }
  };

  const renderEmailStep = (): JSX.Element => (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader className="text-center">
        <div className="mx-auto w-12 h-12 bg-emerald-100 rounded-full flex items-center justify-center mb-4">
          <Mail className="h-6 w-6 text-emerald-600" />
        </div>
        <CardTitle>Profile Verification</CardTitle>
        <p className="text-sm text-gray-600">
          Enter your whitelisted email address to begin verification
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        {allocationInfo && (
          <Alert>
            <Gift className="h-4 w-4" />
            <AlertDescription>
              <strong>Early Adopter Bonus:</strong> First {allocationInfo.totalAllocated + allocationInfo.remainingAllocations} verified users receive {allocationInfo.allocationPerUser} AHP tokens!
            </AlertDescription>
          </Alert>
        )}

        <form onSubmit={handleEmailSubmit} className="space-y-4">
          <div>
            <Label htmlFor="email">Email Address</Label>
            <Input
              id="email"
              type="email"
              placeholder="your@email.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          
          <Button type="submit" className="w-full" disabled={isLoading}>
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Checking...
              </>
            ) : (
              'Check Email'
            )}
          </Button>
        </form>

        {error && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}
      </CardContent>
    </Card>
  );

  const renderVerifyStep = (): JSX.Element => (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader className="text-center">
        <div className="mx-auto w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-4">
          <Shield className="h-6 w-6 text-blue-600" />
        </div>
        <CardTitle>Wallet Verification</CardTitle>
        <p className="text-sm text-gray-600">
          Connect your wallet and sign a message to complete verification
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-3">
          <div className="flex items-center justify-between p-3 bg-gray-50 rounded-md">
            <span className="text-sm font-medium">Email:</span>
            <span className="font-mono text-sm">{email}</span>
          </div>
          
          <div className="flex items-center justify-between p-3 bg-gray-50 rounded-md">
            <span className="text-sm font-medium">Wallet:</span>
            <span className="font-mono text-sm">
              {walletAddress || 'Not connected'}
            </span>
          </div>
        </div>

        {!isWalletConnected ? (
          <Button onClick={handleConnectWallet} className="w-full" disabled={isWalletConnecting}>
            {isWalletConnecting ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Connecting...
              </>
            ) : (
              <>
                <Shield className="mr-2 h-4 w-4" />
                Connect ZKsync SSO Wallet
              </>
            )}
          </Button>
        ) : (
          <Button onClick={handleWalletVerification} className="w-full" disabled={isLoading}>
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Verifying...
              </>
            ) : (
              'Verify Profile'
            )}
          </Button>
        )}

        {(error || walletError) && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error || walletError}</AlertDescription>
          </Alert>
        )}
      </CardContent>
    </Card>
  );

  const renderCompleteStep = (): JSX.Element => (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader className="text-center">
        <div className="mx-auto w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mb-4">
          <CheckCircle className="h-6 w-6 text-green-600" />
        </div>
        <CardTitle>Verification Complete!</CardTitle>
        <p className="text-sm text-gray-600">
          Your profile has been successfully verified
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        {verificationStatus && (
          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 bg-green-50 rounded-md">
              <span className="text-sm font-medium">User ID:</span>
              <Badge variant="outline">{verificationStatus.userId}</Badge>
            </div>
            
            <div className="flex items-center justify-between p-3 bg-green-50 rounded-md">
              <span className="text-sm font-medium">Email:</span>
              <span className="font-mono text-sm">{verificationStatus.email}</span>
            </div>
            
            <div className="flex items-center justify-between p-3 bg-green-50 rounded-md">
              <span className="text-sm font-medium">Token Allocation:</span>
              <Badge variant="default">
                {verificationStatus.tokenAllocation} AHP
              </Badge>
            </div>
            
            <div className="flex items-center justify-between p-3 bg-green-50 rounded-md">
              <span className="text-sm font-medium">Status:</span>
              <Badge variant="default">
                {verificationStatus.hasReceivedTokens ? 'Tokens Allocated' : 'Allocation Pending'}
              </Badge>
            </div>
          </div>
        )}

        {success && (
          <Alert>
            <CheckCircle className="h-4 w-4" />
            <AlertDescription>{success}</AlertDescription>
          </Alert>
        )}

        <div className="space-y-2">
          <Button 
            onClick={() => window.location.href = '/dashboard'} 
            className="w-full"
          >
            Go to Dashboard
          </Button>
          <Button 
            variant="outline" 
            onClick={() => window.location.href = '/wallet'} 
            className="w-full"
          >
            View Wallet
          </Button>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 to-amber-50 flex items-center justify-center p-6">
      <div className="w-full max-w-2xl">
        {step === 'email' && renderEmailStep()}
        {step === 'verify' && renderVerifyStep()}
        {step === 'complete' && renderCompleteStep()}
        
        {/* Additional Info */}
        <div className="mt-8 text-center">
          <p className="text-sm text-gray-600 mb-4">
            Need help? Contact support or visit our documentation
          </p>
          <div className="flex justify-center gap-4">
            <Button variant="outline" size="sm">
              <ExternalLink className="mr-2 h-4 w-4" />
              Documentation
            </Button>
            <Button variant="outline" size="sm">
              <Mail className="mr-2 h-4 w-4" />
              Contact Support
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};
