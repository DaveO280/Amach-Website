'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Loader2, CheckCircle, AlertCircle, Mail, Shield, Gift, ExternalLink, Wallet } from 'lucide-react';
import { useZkSyncSsoWallet } from '@/hooks/useZkSyncSsoWallet';

interface VerificationStatus {
  isVerified: boolean;
  email?: string;
  userId?: number;
  tokenAllocation?: string;
  hasReceivedTokens?: boolean;
  verificationDate?: string;
}

interface AllocationInfo {
  totalAllocated: number;
  remainingAllocations: number;
  allocationPerUser: string;
  isActive: boolean;
}

export const ZkSyncSsoVerificationFlow: React.FC = () => {
  const [email, setEmail] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [verificationStatus, setVerificationStatus] = useState<VerificationStatus | null>(null);
  const [allocationInfo, setAllocationInfo] = useState<AllocationInfo | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [step, setStep] = useState<'email' | 'connect' | 'verify' | 'complete'>('email');
  
  // Use ZKsync SSO wallet hook
  const {
    isConnected: isWalletConnected,
    isConnecting: isWalletConnecting,
    address: walletAddress,
    connect: connectWallet,
    error: walletError,
    clearError: clearWalletError
  } = useZkSyncSsoWallet();

  // Use the ZKsync SSO service for verification
  const verifyProfileZKsync = useCallback(async (email: string): Promise<{ success: boolean; txHash?: string; error?: string }> => {
    try {
      if (!isWalletConnected || !walletAddress) {
        return { success: false, error: 'Wallet not connected' };
      }

      console.log('🔐 Verifying profile using ZKsync SSO service...');

      // Import the service and use its method
      const { zkSyncSsoWalletService } = await import('@/services/ZkSyncSsoWalletService');
      return await zkSyncSsoWalletService.verifyProfileZKsync(email);
    } catch (error) {
      console.error('Failed to verify profile:', error);
      return { 
        success: false, 
        error: error instanceof Error ? error.message : 'Failed to verify profile' 
      };
    }
  }, [isWalletConnected, walletAddress]);

  const loadAllocationInfo = useCallback(async (): Promise<void> => {
    try {
      const response = await fetch('/api/verification/allocation-info');
      if (!response.ok) {
        throw new Error('Failed to load allocation info');
      }
      const data = await response.json();
      setAllocationInfo(data);
    } catch (error) {
      console.error('Failed to load allocation info:', error);
      setError('Failed to load allocation information');
    }
  }, []);

  const checkEmailWhitelist = useCallback(async (email: string): Promise<boolean> => {
    try {
      // Use real API endpoint to check contract
      const response = await fetch('/api/verification/check-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email })
      });

      if (!response.ok) {
        throw new Error('Failed to check email status');
      }

      const data = await response.json();
      console.log('Email check result:', data);
      return data.canProceed;
    } catch (error) {
      console.error('Failed to check email whitelist:', error);
      return false;
    }
  }, []);

  const checkVerificationStatus = useCallback(async (): Promise<void> => {
    try {
      const response = await fetch('/api/verification/check-status', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email })
      });

      if (response.ok) {
        const data = await response.json();
        setVerificationStatus(data);
        
        if (data.isVerified) {
          setStep('complete');
          setSuccess('Profile already verified!');
        }
      }
    } catch (error) {
      console.error('Failed to check verification status:', error);
    }
  }, [email]);

  // Load allocation info on mount
  useEffect(() => {
    loadAllocationInfo();
  }, [loadAllocationInfo]);

  // Check verification status when wallet connects
  useEffect(() => {
    if (isWalletConnected && walletAddress && email) {
      checkVerificationStatus();
    }
  }, [isWalletConnected, walletAddress, email, checkVerificationStatus]);

  // Clear errors when step changes
  useEffect(() => {
    if (error) setError(null);
    if (walletError) clearWalletError();
  }, [step, error, walletError, clearWalletError]);

  const handleEmailSubmit = async (e: React.FormEvent): Promise<void> => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);

    try {
      if (!email) {
        setError('Email is required');
        return;
      }

      // Check if email is whitelisted
      const canProceed = await checkEmailWhitelist(email);
      
      if (!canProceed) {
        setError('Email is not whitelisted or already in use');
        return;
      }

      // Move to wallet connection step
      setStep('connect');
      setSuccess('Email verified! Now connect your wallet.');
      
    } catch (error) {
      setError('Failed to verify email');
    } finally {
      setIsLoading(false);
    }
  };

  const handleConnectWallet = async (): Promise<void> => {
    try {
      setError(null);
      const result = await connectWallet();
      if (result.success) {
        setStep('verify');
        setSuccess('Wallet connected! Ready for verification.');
      } else {
        setError(result.error || 'Failed to connect wallet');
      }
    } catch (error) {
      setError('Failed to connect wallet');
    }
  };

  const handleWalletVerification = async (): Promise<void> => {
    if (!walletAddress || !email) {
      setError('Wallet address and email are required');
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      console.log('🔐 Starting verification process...');
      console.log('📧 Email:', email);
      console.log('💰 Wallet:', walletAddress);
      
      // Use ZKsync SSO verification (no signature required)
      const verifyResult = await verifyProfileZKsync(email);
      if (!verifyResult.success) {
        setError(verifyResult.error || 'Failed to verify profile');
        return;
      }

      console.log('✅ Verification transaction submitted:', verifyResult.txHash);

      // Wait a moment for the transaction to be processed
      await new Promise(resolve => setTimeout(resolve, 2000));

      // Check verification status
      await checkVerificationStatus();

      // Set verification status
      setVerificationStatus({
        isVerified: true,
        email: email,
        userId: 1, // Will be updated by checkVerificationStatus
        tokenAllocation: allocationInfo?.allocationPerUser || '1000',
        hasReceivedTokens: true,
        verificationDate: new Date().toISOString()
      });

      setStep('complete');
      setSuccess(`Profile verified successfully! You have been allocated ${allocationInfo?.allocationPerUser || '1000'} AHP tokens.`);
      
      console.log('✅ Verification completed successfully');
      
    } catch (error) {
      console.error('Verification failed:', error);
      setError(error instanceof Error ? error.message : 'Verification failed');
    } finally {
      setIsLoading(false);
    }
  };

  const renderEmailStep = (): JSX.Element => (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader className="text-center">
        <div className="mx-auto w-12 h-12 bg-emerald-100 rounded-full flex items-center justify-center mb-4">
          <Mail className="h-6 w-6 text-emerald-600" />
        </div>
        <CardTitle>Profile Verification</CardTitle>
        <p className="text-sm text-gray-600">
          Enter your whitelisted email address to begin verification
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        {allocationInfo && (
          <Alert>
            <Gift className="h-4 w-4" />
            <AlertDescription>
              <strong>Early Adopter Bonus:</strong> First {allocationInfo.totalAllocated + allocationInfo.remainingAllocations} verified users receive {allocationInfo.allocationPerUser} AHP tokens!
            </AlertDescription>
          </Alert>
        )}

        <form onSubmit={handleEmailSubmit} className="space-y-4">
          <div>
            <Label htmlFor="email">Email Address</Label>
            <Input
              id="email"
              type="email"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>

          <Button type="submit" className="w-full" disabled={isLoading}>
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Checking...
              </>
            ) : (
              'Verify Email'
            )}
          </Button>
        </form>

        {error && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {success && (
          <Alert>
            <CheckCircle className="h-4 w-4" />
            <AlertDescription>{success}</AlertDescription>
          </Alert>
        )}
      </CardContent>
    </Card>
  );

  const renderConnectStep = (): JSX.Element => (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader className="text-center">
        <div className="mx-auto w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-4">
          <Wallet className="h-6 w-6 text-blue-600" />
        </div>
        <CardTitle>Connect ZKsync SSO Wallet</CardTitle>
        <p className="text-sm text-gray-600">
          Connect your ZKsync SSO wallet to complete verification
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="p-4 bg-gray-50 rounded-lg">
          <p className="text-sm text-gray-600 mb-2">
            <strong>Email:</strong> {email}
          </p>
          <p className="text-sm text-gray-600">
            <strong>Status:</strong> ✅ Whitelisted and ready
          </p>
        </div>

        <Button 
          onClick={handleConnectWallet} 
          className="w-full" 
          disabled={isWalletConnecting}
          size="lg"
        >
          {isWalletConnecting ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Connecting...
            </>
          ) : (
            <>
              <Shield className="mr-2 h-4 w-4" />
              Connect ZKsync SSO Wallet
            </>
          )}
        </Button>

        <div className="text-center">
          <Button 
            variant="outline" 
            onClick={() => setStep('email')}
            className="text-sm"
          >
            ← Back to Email
          </Button>
        </div>

        {(error || walletError) && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              {error || walletError}
            </AlertDescription>
          </Alert>
        )}

        {success && (
          <Alert>
            <CheckCircle className="h-4 w-4" />
            <AlertDescription>{success}</AlertDescription>
          </Alert>
        )}
      </CardContent>
    </Card>
  );

  const renderVerifyStep = (): JSX.Element => (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader className="text-center">
        <div className="mx-auto w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mb-4">
          <CheckCircle className="h-6 w-6 text-green-600" />
        </div>
        <CardTitle>Complete Verification</CardTitle>
        <p className="text-sm text-gray-600">
          Verify your profile to claim your token allocation
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-3">
          <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
            <span className="text-sm font-medium">Email:</span>
            <span className="text-sm text-gray-600">{email}</span>
          </div>
          
          <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
            <span className="text-sm font-medium">Wallet:</span>
            <span className="text-sm text-gray-600 font-mono">
              {walletAddress ? `${walletAddress.slice(0, 6)}...${walletAddress.slice(-4)}` : 'Not connected'}
            </span>
          </div>
        </div>

        <Button 
          onClick={handleWalletVerification} 
          className="w-full" 
          disabled={isLoading || !isWalletConnected}
          size="lg"
        >
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Verifying...
            </>
          ) : (
            <>
              <Shield className="mr-2 h-4 w-4" />
              Verify Profile
            </>
          )}
        </Button>

        <div className="text-center space-x-4">
          <Button 
            variant="outline" 
            onClick={() => setStep('connect')}
            className="text-sm"
          >
            ← Back to Connect
          </Button>
        </div>

        {error && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {success && (
          <Alert>
            <CheckCircle className="h-4 w-4" />
            <AlertDescription>{success}</AlertDescription>
          </Alert>
        )}
      </CardContent>
    </Card>
  );

  const renderCompleteStep = (): JSX.Element => (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader className="text-center">
        <div className="mx-auto w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-4">
          <CheckCircle className="h-8 w-8 text-green-600" />
        </div>
        <CardTitle className="text-green-800">Verification Complete!</CardTitle>
        <p className="text-sm text-gray-600">
          Your profile has been successfully verified
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        {verificationStatus && (
          <div className="space-y-3">
            <div className="flex justify-between items-center p-3 bg-green-50 rounded-lg">
              <span className="text-sm font-medium">User ID:</span>
              <Badge variant="secondary">{verificationStatus.userId}</Badge>
            </div>
            
            <div className="flex justify-between items-center p-3 bg-green-50 rounded-lg">
              <span className="text-sm font-medium">Token Allocation:</span>
              <Badge className="bg-green-600">{verificationStatus.tokenAllocation} AHP</Badge>
            </div>
            
            {verificationStatus.verificationDate && (
              <div className="flex justify-between items-center p-3 bg-green-50 rounded-lg">
                <span className="text-sm font-medium">Verified:</span>
                <span className="text-sm text-gray-600">
                  {new Date(verificationStatus.verificationDate).toLocaleDateString()}
                </span>
              </div>
            )}
          </div>
        )}

        <Alert>
          <Gift className="h-4 w-4" />
          <AlertDescription>
            <strong>Congratulations!</strong> You&apos;ve successfully verified your profile and secured your early adopter token allocation.
          </AlertDescription>
        </Alert>

        <div className="space-y-2">
          <Button 
            onClick={() => window.location.href = '/'} 
            className="w-full"
          >
            Go to Main Website
          </Button>
          
          <Button 
            variant="outline" 
            onClick={() => window.location.href = '/wallet'} 
            className="w-full"
          >
            View Wallet
          </Button>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-white to-emerald-50 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {step === 'email' && renderEmailStep()}
        {step === 'connect' && renderConnectStep()}
        {step === 'verify' && renderVerifyStep()}
        {step === 'complete' && renderCompleteStep()}
        
        {/* Help Section */}
        <div className="mt-8 text-center">
          <p className="text-sm text-gray-500 mb-2">
            Need help with verification?
          </p>
          <Button 
            variant="link" 
            onClick={() => window.open('https://portal.zksync.io/', '_blank')}
            className="text-sm"
          >
            <ExternalLink className="mr-1 h-3 w-3" />
            ZKsync Portal
          </Button>
        </div>
      </div>
    </div>
  );
};
