import { NextRequest, NextResponse } from 'next/server';

// Force Node.js runtime for API access
export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

export async function POST(request: NextRequest): Promise<NextResponse> {
  let email: string | undefined;
  
  try {
    console.log('🔍 API: check-email endpoint called (calling admin app API)');
    
    const body = await request.json();
    email = body.email;
    console.log('📧 API: Received email:', email);

    if (!email) {
      console.log('❌ API: Email is required');
      return NextResponse.json(
        { error: 'Email is required' },
        { status: 400 }
      );
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      console.log('❌ API: Invalid email format');
      return NextResponse.json(
        { error: 'Invalid email format' },
        { status: 400 }
      );
    }

    console.log('📡 API: Calling admin app whitelist API...');

    // Call admin app's whitelist API instead of direct database access
    const adminResponse = await fetch('http://localhost:3001/api/whitelist');
    const adminData = await adminResponse.json();
    
    if (!adminData.success) {
      throw new Error('Failed to fetch whitelist from admin app');
    }

    // Check if email is in the whitelist
    const isWhitelisted = adminData.whitelist.some((item: any) => 
      item.email.toLowerCase() === email.toLowerCase() && item.status === 'active'
    );
    
    // For now, we'll assume email is not "in use" since we're not tracking that in the database
    // In the future, this could be enhanced to check verification records
    const isInUse = false;
    
    const result = {
      email,
      isWhitelisted,
      isInUse,
      canProceed: isWhitelisted && !isInUse,
      source: 'admin_api'
    };

    console.log('✅ API: Admin API check successful');
    console.log('📤 API: Returning result:', result);
    
    return NextResponse.json(result);

  } catch (error) {
    console.error('❌ API: Failed to check email:', error);
    console.error('❌ API: Error details:', {
      message: error instanceof Error ? error.message : 'Unknown error',
      stack: error instanceof Error ? error.stack : undefined
    });
    
    // Fallback: return not whitelisted if admin API access fails
    return NextResponse.json({
      email: email || 'unknown',
      isWhitelisted: false,
      isInUse: false,
      canProceed: false,
      source: 'admin_api_error',
      error: 'Admin API access failed'
    });
  }
}
