import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';

export const runtime = 'nodejs';

// Simple file-based tracking for now (could be replaced with database later)
const TRACKING_FILE = path.join(process.cwd(), 'tracking-data.json');

// Initialize tracking file if it doesn't exist
function initializeTrackingFile() {
  if (!fs.existsSync(TRACKING_FILE)) {
    fs.writeFileSync(TRACKING_FILE, JSON.stringify({ events: [] }));
  }
}

// GET - Retrieve tracking data for admin dashboard
export async function GET(): Promise<NextResponse> {
  try {
    initializeTrackingFile();
    const data = JSON.parse(fs.readFileSync(TRACKING_FILE, 'utf8'));
    
    return NextResponse.json({
      success: true,
      events: data.events || []
    }, {
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization',
      }
    });
  } catch (error) {
    console.error('Failed to get tracking data:', error);
    return NextResponse.json(
      { error: 'Failed to fetch tracking data' },
      { status: 500 }
    );
  }
}

// POST - Add tracking event
export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    const trackingData = await request.json();
    
    initializeTrackingFile();
    const data = JSON.parse(fs.readFileSync(TRACKING_FILE, 'utf8'));
    
    // Add timestamp and event ID
    const event = {
      id: Date.now().toString(),
      timestamp: new Date().toISOString(),
      ...trackingData
    };
    
    data.events.push(event);
    
    // Keep only last 1000 events to prevent file from growing too large
    if (data.events.length > 1000) {
      data.events = data.events.slice(-1000);
    }
    
    fs.writeFileSync(TRACKING_FILE, JSON.stringify(data, null, 2));
    
    console.log('📊 Tracking event stored:', {
      action: trackingData.action,
      email: trackingData.email,
      walletAddress: trackingData.walletAddress
    });
    
    return NextResponse.json({
      success: true,
      eventId: event.id,
      message: 'Tracking event stored successfully'
    }, {
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization',
      }
    });
  } catch (error) {
    console.error('Failed to store tracking data:', error);
    return NextResponse.json(
      { error: 'Failed to store tracking data' },
      { status: 500 }
    );
  }
}

// OPTIONS - Handle CORS preflight requests
export async function OPTIONS(): Promise<NextResponse> {
  return new NextResponse(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    },
  });
}
