"use client";

import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useZkSyncSsoWallet } from "@/hooks/useZkSyncSsoWallet";
import {
  AlertCircle,
  ArrowRight,
  CheckCircle,
  Gift,
  Loader2,
  Mail,
  Shield,
  User,
  Wallet,
} from "lucide-react";
import React, { useCallback, useEffect, useState } from "react";

interface VerificationStatus {
  isVerified: boolean;
  email?: string;
  userId?: number;
  tokenAllocation?: string;
  hasReceivedTokens?: boolean;
  verificationDate?: string;
}

interface AllocationInfo {
  totalAllocated: number;
  remainingAllocations: number;
  allocationPerUser: string;
  isActive: boolean;
  userAllocation?: {
    isVerified: boolean;
    email: string;
    userId: number;
    allocationAmount: string;
    hasClaimed: boolean;
    timestamp: number;
  };
}

interface HealthProfileData {
  birthDate: string;
  sex: string;
  height: number;
  weight: number;
  email: string;
}

type FlowStep = "email" | "wallet" | "profile" | "verify" | "complete";

export const IntegratedVerificationFlow: React.FC = () => {
  // Flow state
  const [currentStep, setCurrentStep] = useState<FlowStep>("email");
  const [email, setEmail] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  // Profile data
  const [profileData, setProfileData] = useState<HealthProfileData>({
    birthDate: "",
    sex: "",
    height: 0,
    weight: 0,
    email: "",
  });

  // Verification and allocation data
  const [verificationStatus, setVerificationStatus] =
    useState<VerificationStatus | null>(null);
  const [allocationInfo, setAllocationInfo] = useState<AllocationInfo | null>(
    null,
  );

  // Wallet hook
  const {
    isConnected: isWalletConnected,
    isConnecting: isWalletConnecting,
    address: walletAddress,
    connect: connectWallet,
    healthProfile,
    updateHealthProfile,
    isProfileLoading,
  } = useZkSyncSsoWallet();

  const loadAllocationInfo = useCallback(async (): Promise<void> => {
    try {
      const response = await fetch("/api/verification/allocation-info");
      const data = await response.json();
      setAllocationInfo(data);
    } catch (error) {
      console.error("Failed to load allocation info:", error);
    }
  }, []);

  // Load allocation info on mount
  useEffect(() => {
    loadAllocationInfo();
  }, [loadAllocationInfo]);

  // Auto-advance steps based on state
  useEffect(() => {
    if (isWalletConnected && currentStep === "wallet") {
      setCurrentStep("profile");
    }
  }, [isWalletConnected, currentStep]);

  // Check if profile exists when wallet connects
  useEffect(() => {
    if (isWalletConnected && healthProfile && currentStep === "profile") {
      // Profile already exists, skip to verification
      setCurrentStep("verify");
    }
  }, [isWalletConnected, healthProfile, currentStep]);

  const checkEmailWhitelist = async (email: string): Promise<boolean> => {
    try {
      const response = await fetch("/api/verification/check-email", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });

      const data = await response.json();
      return data.canProceed || false;
    } catch (error) {
      console.error("Failed to check email whitelist:", error);
      return false;
    }
  };

  const handleEmailSubmit = async (): Promise<void> => {
    if (!email) {
      setError("Please enter your email address");
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      console.log("📧 Checking email whitelist status...");
      const canProceed = await checkEmailWhitelist(email);

      if (!canProceed) {
        setError(
          "Email is not whitelisted or is already in use. Please contact an administrator.",
        );
        return;
      }

      console.log("✅ Email is whitelisted, proceeding to wallet connection");
      setProfileData((prev) => ({ ...prev, email }));
      setCurrentStep("wallet");
    } catch (error) {
      setError("Failed to check email status");
    } finally {
      setIsLoading(false);
    }
  };

  const handleConnectWallet = async (): Promise<void> => {
    try {
      setError(null);
      const result = await connectWallet();
      if (!result.success) {
        setError(result.error || "Failed to connect wallet");
      }
    } catch (error) {
      setError("Failed to connect wallet");
    }
  };

  const handleProfileSubmit = async (): Promise<void> => {
    if (
      !profileData.birthDate ||
      !profileData.sex ||
      !profileData.height ||
      !profileData.weight
    ) {
      setError("Please fill in all profile fields");
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      console.log("👤 Creating health profile...");

      // Convert profile data to the format expected by the service
      const healthData = {
        birthDate: profileData.birthDate,
        sex: profileData.sex,
        height: profileData.height,
        weight: profileData.weight,
        email: profileData.email,
        isActive: true,
        version: 1,
        timestamp: Date.now(),
      };

      const result = await updateHealthProfile(healthData);
      if (result.success) {
        console.log("✅ Health profile created successfully");
        setCurrentStep("verify");
      } else {
        setError(result.error || "Failed to create health profile");
      }
    } catch (error) {
      setError("Failed to create health profile");
    } finally {
      setIsLoading(false);
    }
  };

  const handleVerification = async (): Promise<void> => {
    setIsLoading(true);
    setError(null);

    try {
      console.log("🔐 Starting verification process...");

      // First, double-check that the email is whitelisted in the admin database
      console.log("🔍 Re-checking email whitelist status in admin database...");
      const canProceed = await checkEmailWhitelist(email);

      if (!canProceed) {
        setError(
          "Email is not whitelisted in the admin database. Please contact an administrator.",
        );
        return;
      }

      console.log(
        "✅ Email confirmed whitelisted in admin database, proceeding with blockchain verification...",
      );

      // Import the service and use its method
      const { zkSyncSsoWalletService } = await import(
        "@/services/ZkSyncSsoWalletService"
      );
      const verifyResult =
        await zkSyncSsoWalletService.verifyProfileZKsync(email);

      if (!verifyResult.success) {
        setError(verifyResult.error || "Failed to verify profile");
        return;
      }

      console.log("✅ Profile verification successful:", verifyResult.txHash);

      // Wait for transaction to be processed
      await new Promise((resolve) => setTimeout(resolve, 3000));

      // Check verification status
      await checkVerificationStatus();

      setCurrentStep("complete");
      setSuccess(
        `🎉 Congratulations! Your profile has been verified and you've been allocated 1,000 $AHP tokens! You can now claim them in your wallet.`,
      );
    } catch (error) {
      console.error("Verification failed:", error);
      setError(error instanceof Error ? error.message : "Verification failed");
    } finally {
      setIsLoading(false);
    }
  };

  const checkVerificationStatus = async (): Promise<void> => {
    if (!walletAddress) return;

    try {
      const response = await fetch(
        `/api/verification/allocation-info?wallet=${walletAddress}`,
        {
          method: "GET",
          headers: { "Content-Type": "application/json" },
        },
      );

      const data = await response.json();
      if (data.userAllocation && data.userAllocation.isVerified) {
        setVerificationStatus({
          isVerified: true,
          email: data.userAllocation.email,
          userId: data.userAllocation.userId,
          tokenAllocation: data.userAllocation.allocationAmount,
          hasReceivedTokens: data.userAllocation.hasClaimed,
          verificationDate: new Date(
            data.userAllocation.timestamp * 1000,
          ).toISOString(),
        });
      }
    } catch (error) {
      console.error("Failed to check verification status:", error);
    }
  };

  const renderStepIndicator = (): JSX.Element => (
    <div className="flex items-center justify-center mb-6">
      <div className="flex items-center space-x-4">
        {(
          ["email", "wallet", "profile", "verify", "complete"] as FlowStep[]
        ).map((step, index) => {
          const isActive = step === currentStep;
          const isCompleted =
            ["email", "wallet", "profile", "verify", "complete"].indexOf(
              currentStep,
            ) > index;

          return (
            <div key={step} className="flex items-center">
              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                  isCompleted
                    ? "bg-emerald-600 text-white"
                    : isActive
                      ? "bg-emerald-600 text-white"
                      : "bg-amber-100 text-amber-600"
                }`}
              >
                {isCompleted ? <CheckCircle className="w-4 h-4" /> : index + 1}
              </div>
              {index < 4 && (
                <div
                  className={`w-8 h-0.5 ${isCompleted ? "bg-emerald-600" : "bg-amber-200"}`}
                />
              )}
            </div>
          );
        })}
      </div>
    </div>
  );

  const renderEmailStep = (): JSX.Element => (
    <Card className="w-full max-w-md mx-auto bg-white/90 border-emerald-100 shadow-lg backdrop-blur-sm">
      <CardHeader className="text-center">
        <div className="mx-auto w-12 h-12 bg-emerald-100 rounded-full flex items-center justify-center mb-4">
          <Mail className="h-6 w-6 text-emerald-600" />
        </div>
        <CardTitle className="text-emerald-900">
          Step 1: Email Verification
        </CardTitle>
        <p className="text-sm text-amber-800/80">
          Enter your whitelisted email address to begin the verification process
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="email">Email Address</Label>
          <Input
            id="email"
            type="email"
            placeholder="your.email@example.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            disabled={isLoading}
          />
        </div>

        {error && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <Button
          onClick={handleEmailSubmit}
          disabled={isLoading || !email}
          className="w-full bg-emerald-600 hover:bg-emerald-700 text-white"
        >
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Checking Email...
            </>
          ) : (
            <>
              Verify Email
              <ArrowRight className="ml-2 h-4 w-4" />
            </>
          )}
        </Button>
      </CardContent>
    </Card>
  );

  const renderWalletStep = (): JSX.Element => (
    <Card className="w-full max-w-md mx-auto bg-white/90 border-emerald-100 shadow-lg backdrop-blur-sm">
      <CardHeader className="text-center">
        <div className="mx-auto w-12 h-12 bg-emerald-100 rounded-full flex items-center justify-center mb-4">
          <Wallet className="h-6 w-6 text-emerald-600" />
        </div>
        <CardTitle className="text-emerald-900">
          Step 2: Connect Wallet
        </CardTitle>
        <p className="text-sm text-amber-800/80">
          Connect your ZKsync SSO wallet to continue
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="text-center space-y-2">
          <p className="text-sm text-amber-800/80">
            Email: <span className="font-medium text-emerald-900">{email}</span>
          </p>
          <Badge
            variant="outline"
            className="text-emerald-600 border-emerald-600 bg-emerald-50"
          >
            <CheckCircle className="w-3 h-3 mr-1" />
            Email Verified
          </Badge>
        </div>

        {error && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <Button
          onClick={handleConnectWallet}
          disabled={isWalletConnecting}
          className="w-full bg-emerald-600 hover:bg-emerald-700 text-white"
        >
          {isWalletConnecting ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Connecting...
            </>
          ) : (
            <>
              Connect ZKsync SSO Wallet
              <ArrowRight className="ml-2 h-4 w-4" />
            </>
          )}
        </Button>
      </CardContent>
    </Card>
  );

  const renderProfileStep = (): JSX.Element => (
    <Card className="w-full max-w-md mx-auto bg-white/90 border-emerald-100 shadow-lg backdrop-blur-sm">
      <CardHeader className="text-center">
        <div className="mx-auto w-12 h-12 bg-emerald-100 rounded-full flex items-center justify-center mb-4">
          <User className="h-6 w-6 text-emerald-600" />
        </div>
        <CardTitle className="text-emerald-900">
          Step 3: Create Health Profile
        </CardTitle>
        <p className="text-sm text-amber-800/80">
          Create your encrypted health profile on-chain
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="birthDate">Birth Date</Label>
          <Input
            id="birthDate"
            type="date"
            value={profileData.birthDate}
            onChange={(e) =>
              setProfileData((prev) => ({ ...prev, birthDate: e.target.value }))
            }
            disabled={isLoading}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="sex">Sex</Label>
          <select
            id="sex"
            value={profileData.sex}
            onChange={(e) =>
              setProfileData((prev) => ({ ...prev, sex: e.target.value }))
            }
            disabled={isLoading}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="">Select...</option>
            <option value="male">Male</option>
            <option value="female">Female</option>
            <option value="other">Other</option>
          </select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="height">Height (inches)</Label>
          <Input
            id="height"
            type="number"
            placeholder="72"
            value={profileData.height || ""}
            onChange={(e) =>
              setProfileData((prev) => ({
                ...prev,
                height: parseInt(e.target.value) || 0,
              }))
            }
            disabled={isLoading}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="weight">Weight (pounds)</Label>
          <Input
            id="weight"
            type="number"
            placeholder="150"
            value={profileData.weight || ""}
            onChange={(e) =>
              setProfileData((prev) => ({
                ...prev,
                weight: parseInt(e.target.value) || 0,
              }))
            }
            disabled={isLoading}
          />
        </div>

        {error && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <Button
          onClick={handleProfileSubmit}
          disabled={isLoading || isProfileLoading}
          className="w-full bg-emerald-600 hover:bg-emerald-700 text-white"
        >
          {isLoading || isProfileLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Creating Profile...
            </>
          ) : (
            <>
              Create Health Profile
              <ArrowRight className="ml-2 h-4 w-4" />
            </>
          )}
        </Button>
      </CardContent>
    </Card>
  );

  const renderVerifyStep = (): JSX.Element => (
    <Card className="w-full max-w-md mx-auto bg-white/90 border-emerald-100 shadow-lg backdrop-blur-sm">
      <CardHeader className="text-center">
        <div className="mx-auto w-12 h-12 bg-emerald-100 rounded-full flex items-center justify-center mb-4">
          <Shield className="h-6 w-6 text-emerald-600" />
        </div>
        <CardTitle className="text-emerald-900">
          Step 4: Verify Profile
        </CardTitle>
        <p className="text-sm text-amber-800/80">
          Verify your profile on-chain to receive your token allocation
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="text-center space-y-2">
          <p className="text-sm text-amber-800/80">
            Wallet:{" "}
            <span className="font-mono text-xs text-emerald-900">
              {walletAddress}
            </span>
          </p>
          <p className="text-sm text-amber-800/80">
            Email: <span className="font-medium text-emerald-900">{email}</span>
          </p>
          <div className="flex justify-center space-x-2">
            <Badge
              variant="outline"
              className="text-emerald-600 border-emerald-600 bg-emerald-50"
            >
              <CheckCircle className="w-3 h-3 mr-1" />
              Profile Created
            </Badge>
            <Badge
              variant="outline"
              className="text-emerald-600 border-emerald-600 bg-emerald-50"
            >
              <Wallet className="w-3 h-3 mr-1" />
              Wallet Connected
            </Badge>
          </div>
        </div>

        {allocationInfo && (
          <div className="bg-emerald-50 p-3 rounded-lg border border-emerald-200">
            <div className="flex items-center justify-center space-x-2">
              <Gift className="h-5 w-5 text-emerald-600" />
              <span className="text-sm font-medium text-emerald-800">
                Allocation:{" "}
                {allocationInfo.userAllocation
                  ? allocationInfo.userAllocation.allocationAmount
                  : "1,000"}{" "}
                AHP{" "}
                {allocationInfo.userAllocation
                  ? allocationInfo.userAllocation.hasClaimed
                    ? "(Claimed)"
                    : "(Available)"
                  : "(Pending Verification)"}
              </span>
            </div>
          </div>
        )}

        {error && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <Button
          onClick={handleVerification}
          disabled={isLoading}
          className="w-full bg-emerald-600 hover:bg-emerald-700 text-white"
        >
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Verifying...
            </>
          ) : (
            <>
              Verify Profile & Get Allocation
              <ArrowRight className="ml-2 h-4 w-4" />
            </>
          )}
        </Button>
      </CardContent>
    </Card>
  );

  const renderCompleteStep = (): JSX.Element => (
    <Card className="w-full max-w-md mx-auto bg-white/90 border-emerald-100 shadow-lg backdrop-blur-sm">
      <CardHeader className="text-center">
        <div className="mx-auto w-12 h-12 bg-emerald-100 rounded-full flex items-center justify-center mb-4">
          <CheckCircle className="h-6 w-6 text-emerald-600" />
        </div>
        <CardTitle className="text-emerald-900">
          🎉 Verification Complete!
        </CardTitle>
        <p className="text-sm text-amber-800/80">
          Your profile has been verified and your tokens have been allocated
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        {success && (
          <Alert>
            <CheckCircle className="h-4 w-4" />
            <AlertDescription>{success}</AlertDescription>
          </Alert>
        )}

        {verificationStatus && (
          <div className="space-y-3">
            <div className="bg-emerald-50 p-3 rounded-lg border border-emerald-200">
              <div className="flex items-center justify-center space-x-2">
                <Gift className="h-5 w-5 text-emerald-600" />
                <span className="text-lg font-semibold text-emerald-800">
                  1,000 $AHP
                </span>
              </div>
              <p className="text-sm text-emerald-700 text-center mt-1">
                Token Allocation
              </p>
            </div>

            <div className="text-center space-y-2">
              <p className="text-sm text-amber-800/80">
                User ID:{" "}
                <span className="font-medium text-emerald-900">
                  {verificationStatus.userId}
                </span>
              </p>
              <p className="text-sm text-amber-800/80">
                Status:{" "}
                <span className="text-emerald-600 font-medium">Verified</span>
              </p>
            </div>
          </div>
        )}

        <Button
          onClick={() => (window.location.href = "/")}
          className="w-full bg-emerald-600 hover:bg-emerald-700 text-white"
        >
          Go to Main Website
        </Button>
      </CardContent>
    </Card>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 via-white to-emerald-50 flex items-center justify-center p-4">
      <div className="w-full max-w-lg">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-emerald-900 mb-2">
            Amach Health Verification
          </h1>
          <p className="text-amber-800/80">
            Complete your profile verification and claim your $AHP tokens
          </p>
        </div>

        {renderStepIndicator()}

        {currentStep === "email" && renderEmailStep()}
        {currentStep === "wallet" && renderWalletStep()}
        {currentStep === "profile" && renderProfileStep()}
        {currentStep === "verify" && renderVerifyStep()}
        {currentStep === "complete" && renderCompleteStep()}
      </div>
    </div>
  );
};
