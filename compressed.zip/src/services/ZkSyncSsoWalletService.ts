'use client';

import { connect, disconnect, getAccount } from '@wagmi/core';
import { wagmiConfig, ssoConnector } from '../lib/zksync-sso-config';
import { parseEther, type Address } from 'viem';
import { trackingService } from '../utils/trackingService';

// ZKsync Sepolia Testnet chain ID
const ZKSYNC_SEPOLIA_CHAIN_ID = 300;

// Health profile data interface
export interface HealthProfileData {
  birthDate?: string;
  sex?: string;
  height?: number;
  email?: string;
  weight?: number;
  isActive: boolean;
  version: number;
  timestamp: number;
}

// Encrypted profile data for on-chain storage
export interface EncryptedHealthProfile {
  encryptedBirthDate: `0x${string}`;
  encryptedSex: `0x${string}`;
  encryptedHeight: `0x${string}`;
  encryptedEmail: `0x${string}`;
  encryptedWeight: `0x${string}`;
  dataHash: `0x${string}`;
  timestamp: number;
  isActive: boolean;
  version: number;
  zkProofHash: `0x${string}`;
}

// Session management for health data access
export interface HealthDataSession {
  sessionId: string;
  permissions: string[];
  expiryTime: number;
  maxGasFee: bigint;
  isActive: boolean;
}

// ZKsync SSO Wallet Service
export class ZkSyncSsoWalletService {
  private isConnected = false;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private account: any = null;
  private healthProfile: EncryptedHealthProfile | null = null;
  private activeSession: HealthDataSession | null = null;

  constructor() {
    this.initializeService();
  }

  private async initializeService(): Promise<void> {
    try {
      // Attempt to reconnect to any previously authorized connector
      try {
        const { reconnect } = await import('@wagmi/core');
        await reconnect(wagmiConfig);
      } catch {
        // no-op: reconnect not available or failed silently
      }

      // Check if already connected after reconnect attempt
      const account = getAccount(wagmiConfig);
      if (account.isConnected && account.address) {
        this.isConnected = true;
        this.account = account;
        await this.loadHealthProfile();
        console.log('✅ ZKsync SSO service initialized with connected account:', account.address);
      } else {
        console.log('ZKsync SSO service initialized, no account connected');
      }
    } catch (error) {
      console.error('Failed to initialize ZKsync SSO service:', error);
      
      // Handle authorization errors gracefully in development
      if (error instanceof Error && error.message.includes('not been authorized')) {
        console.error('❌ ZKsync SSO AUTHORIZATION REQUIRED ❌');
        console.error('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
        console.error('The domain https://localhost:3000 needs to be authorized.');
        console.error('');
        console.error('📋 STEPS TO AUTHORIZE:');
        console.error('  1. Visit: https://portal.zksync.io/');
        console.error('  2. Connect your wallet');
        console.error('  3. Navigate to "SSO" or "Applications"');
        console.error('  4. Add domain: https://localhost:3000');
        console.error('  5. Save and refresh this page');
        console.error('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
      }
    }
  }

  /**
   * Connect to ZKsync SSO wallet
   */
  async connect(): Promise<{ success: boolean; error?: string }> {
    try {
      // Ensure we're running on the client side
      if (typeof window === 'undefined') {
        return { success: false, error: 'ZKsync SSO can only be used on the client side' };
      }

      console.log('🔐 Connecting to ZKsync SSO wallet...');
      
      // Use ZKsync Sepolia chain ID directly
      console.log('🔗 Using ZKsync Sepolia chain ID:', ZKSYNC_SEPOLIA_CHAIN_ID);
      
      const result = await connect(wagmiConfig, {
        connector: ssoConnector,
        chainId: ZKSYNC_SEPOLIA_CHAIN_ID,
      });

      if (result) {
        this.isConnected = true;
        this.account = result;
        await this.loadHealthProfile();
        
        console.log('✅ Connected to ZKsync SSO wallet:', result);

        return { success: true };
      } else {
        return { success: false, error: 'Failed to connect to wallet' };
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      console.error('❌ ZKsync SSO connection failed:', errorMessage);
      
      // Provide helpful guidance for common errors
      if (errorMessage.includes('not been authorized')) {
        console.error('❌ ZKsync SSO AUTHORIZATION REQUIRED ❌');
        console.error('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
        console.error('The domain https://localhost:3000 needs to be authorized.');
        console.error('');
        console.error('📋 STEPS TO AUTHORIZE:');
        console.error('  1. Visit: https://portal.zksync.io/');
        console.error('  2. Connect your wallet');
        console.error('  3. Navigate to "SSO" or "Applications"');
        console.error('  4. Add domain: https://localhost:3000');
        console.error('  5. Save and refresh this page');
        console.error('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
        return { 
          success: false, 
          error: '🔒 Domain Authorization Required: Please authorize https://localhost:3000 at portal.zksync.io (see console for detailed steps)' 
        };
      }
      
      if (errorMessage.includes('network') || errorMessage.includes('Network')) {
        console.warn('💡 Network Detection Issue:');
        console.warn('   1. Clear browser storage and refresh');
        console.warn('   2. Check if localhost:3000 is authorized at portal.zksync.io');
        return { success: false, error: 'Network detection failed. Please clear browser storage and reconnect.' };
      }
      
      return { success: false, error: errorMessage };
    }
  }

  /**
   * Disconnect from ZKsync SSO wallet
   */
  async disconnect(): Promise<void> {
    try {
      await disconnect(wagmiConfig);
      this.isConnected = false;
      this.account = null;
      this.healthProfile = null;
      this.activeSession = null;
      console.log('🔌 Disconnected from ZKsync SSO wallet');
    } catch (error) {
      console.error('Error disconnecting from wallet:', error);
    }
  }

  /**
   * Refresh ZKsync SSO session to resolve timing issues
   */
  async refreshSession(): Promise<{ success: boolean; error?: string }> {
    try {
      console.log('🔄 Refreshing ZKsync SSO session...');
      
      // Disconnect first
      await this.disconnect();
      
      // Wait a moment for cleanup
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Reconnect with fresh session
      const result = await this.connect();
      
      if (result.success) {
        console.log('✅ ZKsync SSO session refreshed successfully');
      }
      
      return result;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      console.error('❌ Failed to refresh ZKsync SSO session:', errorMessage);
      return { success: false, error: errorMessage };
    }
  }

  /**
   * Force cleanup of ZKsync SSO state (for development/debugging)
   */
  async forceCleanup(): Promise<{ success: boolean; error?: string }> {
    try {
      console.log('🧹 Force cleaning ZKsync SSO state...');
      
      // Disconnect if connected
      if (this.isConnected) {
        await this.disconnect();
      }
      
      // Clear local state
      this.isConnected = false;
      this.account = null;
      this.healthProfile = null;
      this.activeSession = null;
      
      // Clear browser storage related to ZKsync SSO
      if (typeof window !== 'undefined') {
        try {
          // Clear localStorage keys that might be related to ZKsync SSO
          const keysToRemove = [];
          for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            if (key && (key.includes('zksync') || key.includes('sso') || key.includes('wagmi'))) {
              keysToRemove.push(key);
            }
          }
          
          keysToRemove.forEach(key => {
            localStorage.removeItem(key);
            console.log('🗑️ Removed localStorage key:', key);
          });
          
          // Clear sessionStorage
          sessionStorage.clear();
          
          console.log('✅ Browser storage cleaned');
        } catch (storageError) {
          console.warn('⚠️ Could not clear browser storage:', storageError);
        }
      }
      
      // Wait for cleanup to complete
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      console.log('✅ ZKsync SSO state cleanup completed');
      return { success: true };
      
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      console.error('❌ Failed to cleanup ZKsync SSO state:', errorMessage);
      return { success: false, error: errorMessage };
    }
  }

  /**
   * Verify profile using ZKsync SSO (direct contract call, no signature needed)
   */
  async verifyProfileZKsync(email: string, retryCount: number = 0): Promise<{ success: boolean; txHash?: string; error?: string }> {
    try {
      // Ensure we're running on the client side
      if (typeof window === 'undefined') {
        return { success: false, error: 'ZKsync SSO verification can only be used on the client side' };
      }

      if (!this.isConnected || !this.account?.address) {
        return { success: false, error: 'Wallet not connected' };
      }

      console.log('🔐 Verifying profile using ZKsync SSO (direct contract call)...');

      // Use writeContract to call verifyProfileZKsync directly
      const { writeContract } = await import('@wagmi/core');
      
      const hash = await writeContract(wagmiConfig, {
        address: '0xC62283a6667396A4D77EFD0eDEfAB8C505679109',
        abi: [
          {
            "inputs": [
              {"name": "email", "type": "string"}
            ],
            "name": "verifyProfileZKsync",
            "outputs": [],
            "stateMutability": "nonpayable",
            "type": "function"
          }
        ],
        functionName: 'verifyProfileZKsync',
        args: [email],
      });

      console.log('✅ Profile verification transaction submitted:', hash);
      
      // Track the verification in the admin dashboard
      try {
        await trackingService.trackProfileVerification(email, this.account.address);
        console.log('📊 Profile verification tracked successfully');
      } catch (trackingError) {
        console.warn('⚠️ Failed to track verification (non-critical):', trackingError);
      }
      
      return { success: true, txHash: hash };
    } catch (error) {
      console.error('Failed to verify profile:', error);
      
      // Check if it's a session policy error
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      if (errorMessage.includes('Transaction does not fit any policy')) {
        console.log('🔄 Session policy error detected. Please refresh the ZKsync SSO session.');
        return { success: false, error: 'ZKsync SSO session policy error. Please disconnect and reconnect your wallet to refresh the session.' };
      }
      
      // Check if it's a timestamp error and we haven't retried yet
      if (errorMessage.includes('block.timestamp is too close to the range end') && retryCount < 1) {
        console.log('🔄 Timestamp error detected, refreshing session and retrying...');
        
        // Refresh session
        const refreshResult = await this.refreshSession();
        if (refreshResult.success) {
          // Retry with incremented count
          return this.verifyProfileZKsync(email, retryCount + 1);
        } else {
          return { success: false, error: 'Failed to refresh session: ' + refreshResult.error };
        }
      }
      
      return { 
        success: false, 
        error: errorMessage
      };
    }
  }


  /**
   * Check if wallet is connected
   */
  isWalletConnected(): boolean {
    return this.isConnected && this.account !== null;
  }

  /**
   * Refresh connection state from wagmi
   */
  refreshConnectionState(): void {
    try {
      const account = getAccount(wagmiConfig);
      const wasConnected = this.isConnected;
      const wasAccount = this.account;
      
      if (account.isConnected && account.address) {
        this.isConnected = true;
        this.account = account;
        
        // Only log if state actually changed
        if (!wasConnected || wasAccount?.address !== account.address) {
          console.log('🔄 Connection state refreshed:', account.address);
        }
      } else {
        this.isConnected = false;
        this.account = null;
        
        // Only log if state actually changed
        if (wasConnected) {
          console.log('🔄 Connection state refreshed: not connected');
        }
      }
    } catch (error) {
      console.error('Failed to refresh connection state:', error);
    }
  }

  /**
   * Get current account address
   */
  getAddress(): string | null {
    return this.account?.address || null;
  }

  /**
   * Get current account info
   */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  getAccountInfo(): any {
    return this.account;
  }

  /**
   * Load health profile from blockchain
   */
  private async loadHealthProfile(): Promise<void> {
    if (!this.account?.address) return;

    try {
      console.log('📖 Loading health profile from blockchain...');
      
      // Read profile from blockchain using SecureHealthProfile contract
      const { readContract } = await import('@wagmi/core');
      const { secureHealthProfileAbi, SECURE_HEALTH_PROFILE_CONTRACT } = await import('../lib/zksync-sso-config');

      // Check if profile exists by getting metadata
      try {
        const profileMetadata = await readContract(wagmiConfig, {
          address: SECURE_HEALTH_PROFILE_CONTRACT,
          abi: secureHealthProfileAbi,
          functionName: 'getProfileMetadata',
          args: [this.account.address],
        });

        // Profile exists - note: actual encrypted strings are stored on-chain
        // but we need to retrieve them (SecureHealthProfile stores full encrypted data, not just metadata)
        this.healthProfile = {
          encryptedBirthDate: 'encrypted_on_chain' as `0x${string}`, // Full encrypted data is on-chain
          encryptedSex: 'encrypted_on_chain' as `0x${string}`,
          encryptedHeight: 'encrypted_on_chain' as `0x${string}`,
          encryptedWeight: 'encrypted_on_chain' as `0x${string}`,
          encryptedEmail: 'encrypted_on_chain' as `0x${string}`,
          dataHash: profileMetadata[3] as `0x${string}`,
          timestamp: Number(profileMetadata[0]),
          isActive: profileMetadata[1],
          version: profileMetadata[2],
          zkProofHash: '0x0000000000000000000000000000000000000000000000000000000000000000' as `0x${string}`,
        };

        console.log('✅ Health profile loaded from blockchain:', {
          dataHash: profileMetadata[3],
          timestamp: new Date(Number(profileMetadata[0]) * 1000).toISOString(),
          isActive: profileMetadata[1],
          version: profileMetadata[2]
        });
      } catch (error) {
        console.log('ℹ️ No health profile found on blockchain');
        this.healthProfile = null;
      }
    } catch (error) {
      console.error('❌ Failed to load health profile:', error);
    }
  }

  /**
   * Update health profile on blockchain
   */
  async updateHealthProfile(profile: HealthProfileData): Promise<{ success: boolean; error?: string; txHash?: string }> {
    if (!this.isConnected) {
      return { success: false, error: 'Wallet not connected' };
    }

    try {
      console.log('💾 Updating health profile on blockchain...');
      
      // 1. Encrypt the profile data
      const encryptedProfile = await this.encryptHealthData(profile);
      
      // 2. Generate data hash for verification
      const dataHash = await this.generateDataHash(encryptedProfile);
      
      // 3. Update the encrypted profile with the correct data hash
      encryptedProfile.dataHash = dataHash;
      
      // 4. Submit transaction to update profile contract
      const txResult = await this.executeHealthProfileTransaction(encryptedProfile, dataHash);
      
      if (txResult.success) {
        this.healthProfile = encryptedProfile;
        console.log('✅ Health profile updated on blockchain:', txResult.txHash);
        
        // Track profile creation in the admin dashboard
        try {
          if (profile.email) {
            await trackingService.trackProfileCreation(profile.email, profile, this.account.address);
            console.log('📊 Profile creation tracked successfully');
          }
        } catch (trackingError) {
          console.warn('⚠️ Failed to track profile creation (non-critical):', trackingError);
        }
        
        return { success: true, txHash: txResult.txHash };
      } else {
        return { success: false, error: txResult.error };
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      console.error('❌ Failed to update health profile:', errorMessage);
      return { success: false, error: errorMessage };
    }
  }

  /**
   * Encrypt health data using AES-256-GCM for full on-chain encryption
   */
  private async encryptHealthData(profile: HealthProfileData): Promise<EncryptedHealthProfile> {
    // Use secure encryption that stores full encrypted strings on-chain
    const { encryptHealthData: encryptSecureData } = await import('../utils/secureHealthEncryption');
    
    const secureProfile = {
      birthDate: profile.birthDate || '',
      sex: profile.sex || '',
      height: profile.height || 0,
      weight: profile.weight || 0,
      email: profile.email || ''
    };

    // Encrypt using AES-256-GCM - stores full encrypted strings, not hashes
    const encryptedProfile = await encryptSecureData(secureProfile, this.account?.address || '', undefined);
    
    // Store decrypted data in local storage for UI population
    const encryptionKey = await this.getOrCreateEncryptionKey();
    this.storeDecryptedProfile(profile, encryptionKey);

    return {
      encryptedBirthDate: encryptedProfile.encryptedBirthDate as `0x${string}`,
      encryptedSex: encryptedProfile.encryptedSex as `0x${string}`,
      encryptedHeight: encryptedProfile.encryptedHeight as `0x${string}`,
      encryptedWeight: encryptedProfile.encryptedWeight as `0x${string}`,
      encryptedEmail: encryptedProfile.encryptedEmail as `0x${string}`,
      dataHash: encryptedProfile.dataHash as `0x${string}`,
      timestamp: Math.floor(Date.now() / 1000), // Unix timestamp
      isActive: profile.isActive,
      version: profile.version,
      zkProofHash: '0x0000000000000000000000000000000000000000000000000000000000000000' as `0x${string}`,
    };
  }

  /**
   * Generate data hash for verification
   */
  private async generateDataHash(profile: EncryptedHealthProfile): Promise<`0x${string}`> {
    // Use proper keccak256 hashing with encodePacked
    // Only hash the 4 fields that are actually stored in the contract
    const { keccak256, encodePacked } = await import('viem');
    
    const dataHash = keccak256(
      encodePacked(
        ['bytes32', 'bytes32', 'bytes32', 'bytes32'],
        [
          profile.encryptedBirthDate,
          profile.encryptedSex,
          profile.encryptedHeight,
          profile.encryptedWeight
        ]
      )
    );
    
    return dataHash as `0x${string}`;
  }

  /**
   * Execute health profile transaction on blockchain
   */
  private async executeHealthProfileTransaction(
    profile: EncryptedHealthProfile, 
    dataHash: string
  ): Promise<{ success: boolean; txHash?: string; error?: string }> {
    try {
      // Use writeContract from wagmi/core for transactions with SecureHealthProfile contract
      const { writeContract } = await import('@wagmi/core');
      const { secureHealthProfileAbi, SECURE_HEALTH_PROFILE_CONTRACT } = await import('../lib/zksync-sso-config');

      // Check if profile exists first
      const { readContract } = await import('@wagmi/core');
      let hasProfile = false;
      try {
        await readContract(wagmiConfig, {
          address: SECURE_HEALTH_PROFILE_CONTRACT,
          abi: secureHealthProfileAbi,
          functionName: 'getProfileMetadata',
          args: [this.account.address],
        });
        hasProfile = true;
      } catch (error) {
        hasProfile = false;
      }
      
      // Prepare transaction data - SecureHealthProfile stores full encrypted strings
      const functionName = hasProfile ? 'updateSecureProfile' : 'createSecureProfile';
      const nonce = '0x' + Math.random().toString(16).substr(2, 16); // Generate random nonce
      
      const args: readonly [string, string, string, string, string, `0x${string}`, string] = [
        profile.encryptedBirthDate as string,
        profile.encryptedSex as string,
        profile.encryptedHeight as string,
        profile.encryptedWeight as string,
        profile.encryptedEmail as string,
        dataHash as `0x${string}`,
        nonce
      ];

      // Execute transaction
      const hash = await writeContract(wagmiConfig, {
        address: SECURE_HEALTH_PROFILE_CONTRACT,
        abi: secureHealthProfileAbi,
        functionName,
        args,
      });
      
      console.log('📝 Transaction submitted:', hash);
      return { success: true, txHash: hash };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      console.error('❌ Transaction failed:', errorMessage);
      return { success: false, error: errorMessage };
    }
  }

  /**
   * Get current health profile
   */
  getHealthProfile(): EncryptedHealthProfile | null {
    return this.healthProfile;
  }

  /**
   * Manually load health profile from blockchain
   */
  async loadHealthProfileFromBlockchain(): Promise<{ success: boolean; error?: string }> {
    if (!this.account?.address) {
      return { success: false, error: 'No account connected' };
    }

    try {
      await this.loadHealthProfile();
      console.log('🔄 Profile reloaded from blockchain');
      return { success: true };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      console.error('❌ Failed to load health profile:', errorMessage);
      return { success: false, error: errorMessage };
    }
  }

  /**
   * Verify data integrity by checking the data hash
   */
  async verifyDataIntegrity(): Promise<{ success: boolean; isValid: boolean; error?: string }> {
    if (!this.healthProfile) {
      return { success: false, isValid: false, error: 'No profile loaded' };
    }

    try {
      // Generate hash from current profile data
      const currentHash = await this.generateDataHash(this.healthProfile);
      
      // Compare with stored hash
      const isValid = currentHash === this.healthProfile.dataHash;
      
      console.log('🔍 Data integrity check:', {
        currentHash,
        storedHash: this.healthProfile.dataHash,
        isValid
      });

      return { success: true, isValid };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      console.error('❌ Data integrity check failed:', errorMessage);
      return { success: false, isValid: false, error: errorMessage };
    }
  }

  /**
   * Get wallet balance
   */
  async getBalance(): Promise<{ success: boolean; balance?: string; error?: string }> {
    if (!this.isConnected) {
      return { success: false, error: 'Wallet not connected' };
    }

    try {
      const { getBalance } = await import('@wagmi/core');
      const { formatEther } = await import('viem');
      
      const balance = await getBalance(wagmiConfig, {
        address: this.account.address,
      });

      return { 
        success: true, 
        balance: formatEther(balance.value) 
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      console.error('❌ Failed to get balance:', errorMessage);
      return { success: false, error: errorMessage };
    }
  }

  /**
   * Get token balances
   */
  async getTokenBalances(): Promise<{ success: boolean; tokens?: Array<{symbol: string; balance: string; address: string}>, error?: string }> {
    if (!this.isConnected) {
      return { success: false, error: 'Wallet not connected' };
    }

    try {
      // For now, return empty array - in production, query token contracts
      // This would integrate with token contracts to get balances
      const tokens: Array<{symbol: string; balance: string; address: string}> = [];
      
      return { success: true, tokens };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      console.error('❌ Failed to get token balances:', errorMessage);
      return { success: false, error: errorMessage };
    }
  }

  /**
   * Send ETH transaction
   */
  async sendETH(to: string, amount: string): Promise<{ success: boolean; txHash?: string; error?: string }> {
    if (!this.isConnected) {
      return { success: false, error: 'Wallet not connected' };
    }

    try {
      const { sendTransaction } = await import('@wagmi/core');
      const { parseEther } = await import('viem');
      
      const hash = await sendTransaction(wagmiConfig, {
        to: to as `0x${string}`,
        value: parseEther(amount),
      });

      console.log('📝 ETH transaction submitted:', hash);
      return { success: true, txHash: hash };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      console.error('❌ ETH transaction failed:', errorMessage);
      return { success: false, error: errorMessage };
    }
  }

  /**
   * Claim token allocation for verified user
   */
  async claimAllocation(): Promise<{ success: boolean; txHash?: string; error?: string }> {
    try {
      if (!this.isConnected || !this.account?.address) {
        return { success: false, error: 'Wallet not connected' };
      }

      console.log('🎁 Claiming token allocation...');

      const { writeContract } = await import('@wagmi/core');
      
      const hash = await writeContract(wagmiConfig, {
        address: '0xC62283a6667396A4D77EFD0eDEfAB8C505679109', // ProfileVerification contract address
        abi: [
          {
            "inputs": [],
            "name": "claimAllocation",
            "outputs": [],
            "stateMutability": "nonpayable",
            "type": "function"
          }
        ],
        functionName: 'claimAllocation',
      });

      console.log('✅ Token allocation claimed successfully:', hash);
      
      // Track the allocation claim in the admin dashboard
      try {
        // We need to get the email somehow - let's try to get it from the health profile
        const email = this.healthProfile?.encryptedEmail || 'unknown@example.com';
        await trackingService.trackAllocationClaim(email, this.account.address, '1000 $AHP');
        console.log('📊 Allocation claim tracked successfully');
      } catch (trackingError) {
        console.warn('⚠️ Failed to track allocation claim (non-critical):', trackingError);
      }
      
      return { success: true, txHash: hash };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      console.error('❌ Failed to claim allocation:', error);
      
      // Check if it's a session policy error
      if (errorMessage.includes('Transaction does not fit any policy')) {
        console.log('🔄 Session policy error detected. ZKsync SSO session needs to be refreshed.');
        return { 
          success: false, 
          error: 'ZKsync SSO session expired. Please disconnect and reconnect your wallet to refresh the session, then try claiming again.' 
        };
      }
      
      return { success: false, error: errorMessage };
    }
  }

  /**
   * Create session for health data access
   */
  async createHealthDataSession(permissions: string[]): Promise<{ success: boolean; session?: HealthDataSession; error?: string }> {
    if (!this.isConnected) {
      return { success: false, error: 'Wallet not connected' };
    }

    try {
      const sessionId = `health_session_${Date.now()}`;
      const session: HealthDataSession = {
        sessionId,
        permissions,
        expiryTime: Date.now() + (24 * 60 * 60 * 1000), // 24 hours
        maxGasFee: parseEther('0.1'),
        isActive: true,
      };

      this.activeSession = session;
      
      console.log('🔑 Health data session created:', sessionId);
      return { success: true, session };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      return { success: false, error: errorMessage };
    }
  }

  /**
   * Get active session
   */
  getActiveSession(): HealthDataSession | null {
    return this.activeSession;
  }

  /**
   * End current session
   */
  endSession(): void {
    if (this.activeSession) {
      this.activeSession.isActive = false;
      this.activeSession = null;
      console.log('🔒 Health data session ended');
    }
  }

  /**
   * Execute health-related transaction
   */
  async executeHealthTransaction(
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    _to: Address,
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    _value: bigint,
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    _data?: string
  ): Promise<{ success: boolean; hash?: string; error?: string }> {
    if (!this.isConnected) {
      return { success: false, error: 'Wallet not connected' };
    }

    try {
      console.log('💸 Executing health transaction...');
      
      // TODO: Implement actual transaction execution
      // This would use the ZKsync SSO session to execute the transaction
      
      // Simulate transaction execution
      const txHash = `0x${Math.random().toString(16).substring(2)}`;
      
      console.log('✅ Health transaction executed:', txHash);
      return { success: true, hash: txHash };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      console.error('❌ Health transaction failed:', errorMessage);
      return { success: false, error: errorMessage };
    }
  }

  /**
   * Verify health data with ZK proof
   */
  async verifyHealthData(dataHash: string, zkProof: string): Promise<boolean> {
    try {
      console.log('🔍 Verifying health data with ZK proof...');
      
      // TODO: Implement actual ZK proof verification
      // This would verify the ZK proof against the data hash
      
      // Simulate verification
      const isValid = dataHash.length > 0 && zkProof.length > 0;
      
      console.log(isValid ? '✅ Health data verified' : '❌ Health data verification failed');
      return isValid;
    } catch (error) {
      console.error('❌ Health data verification error:', error);
      return false;
    }
  }

  /**
   * Get or create encryption key for this wallet
   */
  private async getOrCreateEncryptionKey(): Promise<string> {
    if (!this.account?.address) {
      throw new Error('No wallet connected');
    }

    const storageKey = `health_encryption_key_${this.account.address}`;
    let encryptionKey = localStorage.getItem(storageKey);
    
    if (!encryptionKey) {
      // Generate new encryption key
      const { generateEncryptionKey } = await import('../utils/encryption');
      encryptionKey = generateEncryptionKey();
      localStorage.setItem(storageKey, encryptionKey);
      console.log('🔑 Generated new encryption key for wallet:', this.account.address);
    }
    
    return encryptionKey;
  }

  /**
   * Store decrypted profile data in local storage
   */
  private storeDecryptedProfile(profile: HealthProfileData, encryptionKey: string): void {
    if (!this.account?.address) return;

    const storageKey = `health_profile_${this.account.address}`;
    const profileData = {
      ...profile,
      encryptionKey, // Store with encryption key for decryption
      timestamp: Date.now()
    };
    
    localStorage.setItem(storageKey, JSON.stringify(profileData));
    console.log('💾 Stored decrypted profile in local storage');
  }

  /**
   * Get decrypted profile data from local storage
   */
  getDecryptedProfile(): HealthProfileData | null {
    if (!this.account?.address) return null;

    const storageKey = `health_profile_${this.account.address}`;
    const stored = localStorage.getItem(storageKey);
    
    if (!stored) return null;
    
    try {
      const profileData = JSON.parse(stored);
      // Remove encryption key from returned data
      // eslint-disable-next-line @typescript-eslint/no-unused-vars
      const { encryptionKey, ...profile } = profileData;
      return profile as HealthProfileData;
    } catch (error) {
      console.error('❌ Failed to parse stored profile data:', error);
      return null;
    }
  }

  /**
   * Clear local storage and re-encrypt current profile data
   * This ensures consistency between local storage and on-chain data
   */
  async refreshLocalEncryption(): Promise<{ success: boolean; error?: string }> {
    if (!this.account?.address) {
      return { success: false, error: 'No wallet connected' };
    }

    try {
      // Get current decrypted data
      const currentData = this.getDecryptedProfile();
      if (!currentData) {
        return { success: false, error: 'No local data to refresh' };
      }

      // Clear old local storage
      const storageKey = `health_profile_${this.account.address}`;
      localStorage.removeItem(storageKey);

      // Re-encrypt and store with current encryption key
      const encryptionKey = await this.getOrCreateEncryptionKey();
      this.storeDecryptedProfile(currentData, encryptionKey);

      console.log('🔄 Refreshed local encryption with current key');
      return { success: true };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      console.error('❌ Failed to refresh local encryption:', errorMessage);
      return { success: false, error: errorMessage };
    }
  }

  /**
   * Verify that data is properly encrypted on-chain
   */
  async verifyEncryptionOnChain(): Promise<{ success: boolean; isEncrypted: boolean; error?: string }> {
    if (!this.healthProfile) {
      return { success: false, isEncrypted: false, error: 'No profile loaded' };
    }

    try {
      // Get the decrypted profile from local storage to verify encryption
      const decryptedProfile = this.getDecryptedProfile();
      
      if (!decryptedProfile) {
        console.log('🔍 No local data found for verification');
        return { success: true, isEncrypted: false };
      }

      // Re-encrypt the local data and compare hashes to verify encryption integrity
      const { encryptHealthData: encryptData } = await import('../utils/encryption');
      const { keccak256 } = await import('viem');
      const encryptionKey = await this.getOrCreateEncryptionKey();
      
      console.log('🔍 Verification details:', {
        localData: {
          birthDate: decryptedProfile.birthDate,
          sex: decryptedProfile.sex,
          height: decryptedProfile.height,
          weight: decryptedProfile.weight
        },
        encryptionKeyLength: encryptionKey.length
      });
      
      // Re-encrypt the data to get the ciphertexts
      const birthCipher = encryptData(decryptedProfile.birthDate || '', encryptionKey);
      const sexCipher = encryptData(decryptedProfile.sex || '', encryptionKey);
      const heightCipher = encryptData(decryptedProfile.height?.toString() || '0', encryptionKey);
      const weightCipher = encryptData(decryptedProfile.weight?.toString() || '0', encryptionKey);
      
      console.log('🔍 Ciphertexts:', {
        birthCipher: birthCipher.slice(0, 20) + '...',
        sexCipher: sexCipher.slice(0, 20) + '...',
        heightCipher: heightCipher.slice(0, 20) + '...',
        weightCipher: weightCipher.slice(0, 20) + '...'
      });
      
      // Hash the ciphertexts to match what's stored on-chain
      // Remove the 0x prefix from ciphertexts before hashing
      const birthCipherHex = birthCipher.startsWith('0x') ? birthCipher.slice(2) : birthCipher;
      const sexCipherHex = sexCipher.startsWith('0x') ? sexCipher.slice(2) : sexCipher;
      const heightCipherHex = heightCipher.startsWith('0x') ? heightCipher.slice(2) : heightCipher;
      const weightCipherHex = weightCipher.startsWith('0x') ? weightCipher.slice(2) : weightCipher;
      
      const expectedBirthHash = keccak256(`0x${birthCipherHex}`);
      const expectedSexHash = keccak256(`0x${sexCipherHex}`);
      const expectedHeightHash = keccak256(`0x${heightCipherHex}`);
      const expectedWeightHash = keccak256(`0x${weightCipherHex}`);
      
      // Compare with what's stored on-chain
      const isEncrypted = 
        expectedBirthHash === this.healthProfile.encryptedBirthDate &&
        expectedSexHash === this.healthProfile.encryptedSex &&
        expectedHeightHash === this.healthProfile.encryptedHeight &&
        expectedWeightHash === this.healthProfile.encryptedWeight;
      
      console.log('🔍 Encryption verification:', {
        onChainBirthHash: this.healthProfile.encryptedBirthDate.slice(0, 20) + '...',
        expectedBirthHash: expectedBirthHash.slice(0, 20) + '...',
        onChainSexHash: this.healthProfile.encryptedSex.slice(0, 20) + '...',
        expectedSexHash: expectedSexHash.slice(0, 20) + '...',
        isEncrypted,
        hasLocalData: !!decryptedProfile,
        allHashesMatch: {
          birth: expectedBirthHash === this.healthProfile.encryptedBirthDate,
          sex: expectedSexHash === this.healthProfile.encryptedSex,
          height: expectedHeightHash === this.healthProfile.encryptedHeight,
          weight: expectedWeightHash === this.healthProfile.encryptedWeight
        },
        fullHashes: {
          onChainBirth: this.healthProfile.encryptedBirthDate,
          expectedBirth: expectedBirthHash,
          onChainSex: this.healthProfile.encryptedSex,
          expectedSex: expectedSexHash
        }
      });
      
      return { success: true, isEncrypted };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      console.error('❌ Encryption verification failed:', errorMessage);
      return { success: false, isEncrypted: false, error: errorMessage };
    }
  }
}

// Export singleton instance
export const zkSyncSsoWalletService = new ZkSyncSsoWalletService();
