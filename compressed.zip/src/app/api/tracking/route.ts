import { NextRequest, NextResponse } from 'next/server';

export const runtime = 'nodejs';

// This endpoint forwards tracking data to the admin dashboard
export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    const trackingData = await request.json();
    
    // Store tracking data locally in main app
    const response = await fetch(`${process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'}/api/admin/tracking`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(trackingData),
    });

    if (!response.ok) {
      console.error('Failed to store tracking data locally:', response.status);
      // Don't fail the main request if tracking fails
      return NextResponse.json({ 
        success: true, 
        trackingStored: false,
        message: 'Main operation succeeded, but tracking failed' 
      });
    }

    const result = await response.json();
    return NextResponse.json({ 
      success: true, 
      trackingStored: true,
      trackingResult: result 
    });

  } catch (error) {
    console.error('Failed to store tracking data:', error);
    // Don't fail the main request if tracking fails
    return NextResponse.json({ 
      success: true, 
      trackingStored: false,
      error: 'Tracking failed but main operation succeeded' 
    });
  }
}
