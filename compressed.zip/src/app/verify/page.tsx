"use client";

import { IntegratedVerificationFlow } from "../../components/IntegratedVerificationFlow";

export default function VerifyPage(): JSX.Element {
  return <IntegratedVerificationFlow />;
}